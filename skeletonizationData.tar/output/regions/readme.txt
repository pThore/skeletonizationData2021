this folder contains the regions that are used to demonstrate the skeletonization algorithm proposed by Pierre Thore and Antoine Lucas 2020


In the folder "regions" are stored the regions used for calculating the Time Of Flight and the seeds used for calculating the various skeletons

The "region" files format is the following: each line contains the coordinates of a point (in grid units: the grid size is 201x201 starting at position 0,0 with a cell increment of 1,1.) 
  column, line


Region files have an extension .reg

the seed poisition region files contains a single point while border region files contain several points.

Border Regions: two regions have been used to initiate the Fast Marching the dense region (dense representation of the central hole) and the sparse region (sparse representation of the central hole)
continuousBorder.reg actual set of points used to create the continuousBorderTOF.prop file 
discontinuousBorder.reg actual set of points used to create the discontinuousBorderTOF.prop file 

Seed Regions: 3 seeds have been used in the skeletonization algorithm
seeInterior.reg a single point situated near the central hole
seedMaxTOF.reg a single point situated on the crest of the TOF property
seedOrigin.reg a single point situated near the origin of the grid



