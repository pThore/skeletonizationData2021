this folder contains the grid properties used to demonstrate the skeletonization algorithm proposed by Pierre Thore and Antoine Lucas 2020

the grid size is 201x201 starting at position 0,0 with a cell increment of 1,1. therefore each property has 40401 values.
The property format is simple: it contains 1 value per line stored columnwise
Property files have a .prop extension

example of storage a grid of size 2,3 (2 lines 3 columns)

1	3	5
0	2	4

slowness: it is the only mandatory property. It contains two type of cells: cells with slowness = 1 where front is propagating and cells with slowness = 1000000 where front is not propagating. 

borders: two borders have been used in the paper one with dense representation of the central hole and one with sparse representation
continuousBorder: a property with 1 at each cell border (external and internal) and -9999 elsewhere
discontinuousBorder: a property with 1 at each cell border (external and internal) and -9999 elsewhere

TOF Time Of Flight has been computed using Fast Marching (FM) algorithm using the slowness property and initialized from either the dense or sparse borders
continuousBorderTOF: a property with TOF calculated at each cell starting from the dense border. TOF at border cells is 0
discontinuousBorderTOF: a property with TOF calculated at each cell starting from the sparse border. TOF at border cells is 0

nota: the original grid size is 10x10 this is why TOF increment is 10 at each step.

