this folder contains the data used for the skeletonization algorithm proposed by Pierre Thore and Antoine Lucas 2020

it contains 3 folders:
	"grids" folder containing the property of the synthetic grid
	"regions" folder containing the regions used to initiate the Fast Marching algorithm (for computing the Time Of Flight properties) and the seeds used to initiate the skeletonization
	"skeletons" folder containing the skeletons results computed with different parameters

all files are in ascii and the files format are described in each specific folder

