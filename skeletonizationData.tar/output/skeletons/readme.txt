this folder contains the skeletons resulting from the skeletonization algorithm proposed by Pierre Thore and Antoine Lucas 2020

In this folder are stored the final skeletons computed with different parameters (initial seed position, sparsity factor, TOF grid)

Skeleton files have the .skel extension
Skeleton file format: files are in ascii format 
set of nodes
"SEGMENTS" line separator
set of segments


nodes are in grid coordinates, one node per line: index, column coordinate, line coordinate
segments ar in node index, one segment per line: start node index, end node index

for example a skeleton of the 201,201 grid with 3 branches:
 main branch with 3 points on the first diagonal 
 second branch with 3 points on the third line 
 third branch with 2 points on the third column 
would look like:
1 0 0 	//1st branch
2 1 1 	//1st branch
3 2 2 	//1st branch
6 2 3 	//3rd branch
4 3 2 	//2nd branch
5 4 2 	//2nd branch
SEGMENT
1 2 	//1st branch
2 3 	//1st branch
3 4 	//2nd branch
4 5 	//2nd branch
3 6 	//3rd branch


x	x	x	x	x	x
x	x	o	x	x	x
x	x	o	o	o	x
x	o	x	x	x	x
o	x	x	x	x	x

beware that nodes are not always in increasing index order


skeletons file:
contBorderSeedInteriorSparse50.skel: skeleton computed on the continuousTOF.prop TOF with initial seed seedInterior.reg and a sparsity factor of 50
contBorderSeedMaxTOFSparse50.skel: skeleton computed on the continuousTOF.prop TOF with initial seed seedMaxTOF.reg and a sparsity factor of 50
contBorderSeedOriginSparse50.skel: skeleton computed on the continuousTOF.prop TOF with initial seed seedOrigin.reg and a sparsity factor of 50
discontBorderSeedMaxTOFSparse40.skel: skeleton computed on the discontinuousTOF.prop TOF with initial seed seedMaxTOF.reg and a sparsity factor of 40
discontBorderSeedMaxTOFSparse50.skel: skeleton computed on the discontinuousTOF.prop TOF with initial seed seedMaxTOF.reg and a sparsity factor of 50
discontBorderSeedMaxTOFSparse200.skel: skeleton computed on the discontinuousTOF.prop TOF with initial seed seedMaxTOF.reg and a sparsity factor of 200
discontBorderSeedOriginSparse50.skel: skeleton computed on the discontinuousTOF.prop TOF with initial seed seedOrigin.reg and a sparsity factor of 50
